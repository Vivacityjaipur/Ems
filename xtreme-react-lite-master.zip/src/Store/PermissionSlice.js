import { createSlice } from '@reduxjs/toolkit';

const Permission = [
    {
      title: "Home",
      permission: [
        {
          permission_id: 1,
          title: "Dashboard",
          allowed: false,
        },
        {
          permission_id: 2,
          title: "Policy",
          allowed: false,
        },
        {
          permission_id: 3,
          title: "Assigned Project",
          allowed: false,
        },
      ],
    },
    {
      title: "import log",
      permission: [
        {
          permission_id: 4,
          title: "Add Log",
          allowed: false,
        },
        {
          permission_id: 5,
          title: "Delete Log",
          allowed: false,
        },
        {
          permission_id: 6,
          title: "Edit Log",
          allowed: false,
        },
        {
          permission_id: 7,
          title: "edited log",
          allowed: false,
        },
      ],
    },
    {
      title: "leave",
      permission: [
        {
          permission_id: 8,
          title: "leave",
          allowed: false,
        },
        {
          permission_id: 9,
          title: "leave list",
          allowed: false,
        },
        {
          permission_id: 10,
          title: "leave balance",
          allowed: false,
        },
      ],
    },
    {
      title: "employee",
      permission: [
        {
          permission_id: 11,
          title: "add/remove Employee",
          allowed: false,
        },
        {
          permission_id: 12,
          title: "monthly attendance",
          allowed: false,
        },
        {
          permission_id: 13,
          title: "attendence details(all)",
          allowed: false,
        },
        {
          permission_id: 14,
          title: "employee list",
          allowed: false,
        },
        {
          permission_id: 15,
          title: "edit profile",
          allowed: false,
        },
        {
          permission_id: 16,
          title: "attendence details",
          allowed: false,
        },
      ],
    },
    // {
    //   title: "administration",
    //   permission: [
    //     {
    //       permission_id: 1,
    //       title: "holidays",
    //       allowed: false,
    //     },
    //     {
    //       permission_id: 2,
    //       title: "department",
    //       allowed: false,
    //     },
    //     {
    //       permission_id: 3,
    //       title: "designation",
    //       allowed: false,
    //     },
    //     {
    //       permission_id: 4,
    //       title: "leave application",
    //       allowed: false,
    //     },
    //     {
    //       permission_id: 5,
    //       title: "leave type",
    //       allowed: false,
    //     },
    //     {
    //       permission_id: 6,
    //       title: "leave balance",
    //       allowed: false,
    //     },
    //     {
    //       permission_id: 7,
    //       title: "leave assign",
    //       allowed: false,
    //     },
    //     {
    //       permission_id: 8,
    //       title: "add role",
    //       allowed: false,
    //     },
    //     {
    //       permission_id: 9,
    //       title: "form permission",
    //       allowed: false,
    //       form_permissions: [
    //         {
    //           permission_id: 1,
    //           title: "user wise",
    //           allowed: false,
    //         },
    //         {
    //           permission_id: 2,
    //           title: "group wise",
    //           allowed: false,
    //         },
    //       ],
    //     },
    //   ],
    // },
  ];

const PermissionSlice=createSlice({
    name:'permissions',
    initialState:Permission,
    reducers:{
        ValidatePermissions(state,action){
            state.forEach(element => {
                element.permission.forEach(sbel => {
                   action.payload.forEach(up => {
                    if(sbel.permission_id===up.permission_id){
                        sbel.allowed=true;
                    }
                   });
                });
            });
        }
    }
})

export const PermissionActions=PermissionSlice.actions;
export default PermissionSlice;